$(document).ready(function(){
    // $.ajax({
    //     url : "/GetRole",
    //     success: function(data){
    //     //response from controller
    //         if(true){

    //         }
    //     }
    // });
    // setTimeout(function(){
    //     if($("#pRole")[0].innerText =="ROLE_ADMIN"){
    //         $("#propList")[0].setAttribute("config","show");
    //         $("#propListA")[0].setAttribute("config","show");
    //     }
    //    }, 0);
   

});